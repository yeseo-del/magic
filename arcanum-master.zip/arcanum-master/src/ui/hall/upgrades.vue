<script>

/**
 * Display of hall upgrades.
 */
export default {

}
</script>

<template>

<div>
</div>

</template>

<style scoped>

</style>