export class ModuleManager {

	constructor(){
	}

}