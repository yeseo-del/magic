# webpack-template
My template for using webpack with separate dev and config files.
