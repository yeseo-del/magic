/**
 * CURRENTLY UNUSED.
 */
export default class CharGroup {

	get chars(){ return this._chars; }
	set chars(v){this._chars =v;}

	/**
	 * @property {number} team
	 */
	get team(){return this._team;}
	set team(v){this._team=v;}

	constructor(){
	}

}