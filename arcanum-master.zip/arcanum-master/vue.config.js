module.exports = {

	assetsDir:'css',

	productionSourceMap:false,

	css:{
		extract:true
	}

}